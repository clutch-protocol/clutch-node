use crate::node::database::Database;
use crate::node::signature_keys;
use crate::node::transaction::Transaction;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

#[derive(Debug, Serialize, Deserialize)]
pub struct Block {
    pub index: usize,
    pub previous_hash: String,
    pub author: String,
    pub signature_r: String,
    pub signature_s: String,
    pub signature_v: i32,
    pub hash: String,
    pub transactions: Vec<Transaction>,
}

impl Block {
    fn calculate_hash(&self) -> String {
        let mut hasher = Sha256::new();

        let transactions_hash_string = self
            .transactions
            .iter()
            .map(|tx| format!("{}", tx.hash))
            .collect::<Vec<String>>()
            .join("");

        hasher.update(format!(
            "{}{}{}",
            self.index, self.previous_hash, transactions_hash_string
        ));
        let result = hasher.finalize();
        format!("{:x}", result)
    }

    pub fn new_genesis_block() -> Block {
        let mut genesis_block = Block {
            author: String::new(),
            hash: String::new(),
            signature_r: String::new(),
            signature_s: String::new(),
            signature_v: 0,
            previous_hash: "0".to_string(),
            index: 0,
            transactions: vec![],
        };

        genesis_block.transactions = Transaction::new_genesis_transactions();
        genesis_block.hash = genesis_block.calculate_hash();
        genesis_block
    }

    pub fn new_block(index: usize, previous_hash: String, transactions: Vec<Transaction>) -> Block {
        let mut block = Block {
            author: String::new(),
            signature_r: String::new(),
            signature_s: String::new(),
            signature_v: 0,
            hash: String::new(),
            previous_hash,
            index,
            transactions,
        };

        block.hash = block.calculate_hash();
        block
    }

    pub fn sign(&mut self, author: &str, secret_key: &str) {
        let hash_bytes = self.hash.as_bytes();
        let (r, s, v) = signature_keys::SignatureKeys::sign(secret_key, hash_bytes);

        self.signature_r = r;
        self.signature_s = s;
        self.signature_v = v;
        self.author = author.to_string();
    }

    fn verify_signature(&self) -> bool {
        let author = &self.author;
        let data = self.hash.as_bytes();
        let r = &self.signature_r;
        let s = &self.signature_s;
        let v = self.signature_v;

        signature_keys::SignatureKeys::verify(author, data, r, s, v)
    }

    pub fn get_latest_block(db: &Database) -> Option<Block> {
        match db.get("blockchain", b"blockchain_latest_block") {
            Ok(Some(value)) => {
                let block_str = String::from_utf8(value).unwrap();
                let block: Block = serde_json::from_str(&block_str).unwrap();
                Some(block)
            }
            Ok(None) => None,
            Err(_) => panic!("Failed to retrieve the latest block index"),
        }
    }

    pub fn validate_block(&self, db: &Database) -> bool {
        match Block::get_latest_block(db) {
            Some(latest_block) => {
                if !self.verify_signature() {
                    println!(
                        "Verification failed: Signature does not match for block from author: {}",
                        self.author
                    );
                    return false;
                }

                if self.index != latest_block.index + 1 {
                    println!(
                        "Invalid block: The block index should be {}, but it was {}.",
                        latest_block.index + 1,
                        self.index
                    );
                    return false;
                }

                if self.previous_hash != latest_block.hash {
                    println!(
                        "Invalid block: The previous hash should be {}, but it was {}.",
                        latest_block.hash, self.previous_hash
                    );
                    return false;
                }

                return true;
            }
            None => true,
        }
    }

    pub fn state_block(&self) -> Option<(Vec<Vec<u8>>, Vec<Vec<u8>>)> {
        let mut keys: Vec<Vec<u8>> = Vec::new();
        let mut values: Vec<Vec<u8>> = Vec::new();

        //Add block
        let block_key = format!("block_{}", self.index).into_bytes();
        let block_value = serde_json::to_string(self).unwrap().into_bytes();
        keys.push(block_key);
        values.push(block_value);

        Some((keys, values))
    }

    pub fn state_blockchain(&self) -> Option<(Vec<Vec<u8>>, Vec<Vec<u8>>)> {
        let mut keys: Vec<Vec<u8>> = Vec::new();
        let mut values: Vec<Vec<u8>> = Vec::new();

        // Save the latest block index to the blockchain
        let blockchain_latest_block_key = b"blockchain_latest_block";
        let blockchain_latest_block_value = serde_json::to_string(self).unwrap().into_bytes();

        keys.push(blockchain_latest_block_key.to_vec());
        values.push(blockchain_latest_block_value);

        Some((keys, values))
    }
}
