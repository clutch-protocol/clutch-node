fn main() {
    println!("Hello from the default binary!");
}